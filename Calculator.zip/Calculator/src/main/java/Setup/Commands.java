package Setup;

public class Commands {

	public static final String custom = "--custom";
	public static final String big = "--big";
	public static final String help = "--help";
}
